<div class="panel-container">
    {{$slot}}
</div>