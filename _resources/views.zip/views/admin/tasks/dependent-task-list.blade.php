@foreach($allTasks as $allTask)
    <option value="{{ $allTask->id }}">{{ $allTask->heading }} (@lang('app.dueDate'): {{ $allTask->due_date !='' ?$allTask->due_date->format($global->date_format): '' }})</option>
@endforeach