<?php

return array(
    'menu' =>
    array(
        'meeting' => 'Meeting',
        'zoom' => 'Zoom',
        'room' => 'Room',
        'zoomMeeting' => 'Online Meeting',
        'zoomSetting' => 'Zoom Settings',
    ),
    'meetings' =>
    array(
        'name' => 'Name',
        'venue' => 'Venue',
        'time' => 'Time',
    ),

    'otherView' => 'Other View'
);
