<?php

return array(
    'newMeeting'=>
    array(
        'subject' => 'New Meeting Created',
        'text' => 'New Meeting has been created.',
    ),
    'meetingReminder' => 
    array (
        'subject' => 'Meeting Reminder',
        'text' => 'This is to remind you about the following meeting.',
    ),
    'loginDashboard' => 'Login To Dashboard',
    'thankyouNote' => 'Thank you for using our application!',
    'hello' => 'Hello',
);
