<?php

return array(
    'menu' =>
    array(
        'meeting' => 'Réunion',
        'zoom' => 'zoom',
        'room' => 'Pièce',
        'zoomMeeting' => "Visio-Conférence",
        'zoomSetting' => 'Paramètre Zoom',
    ),
    'meetings' =>
    array(
        'name' => 'Nom',
        'venue' => 'Lieu',
        'time' => 'Temps',
    ),

    'otherView' => 'Autre vue'
);
