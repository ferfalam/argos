<?php

return array(
    'newMeeting'=>
    array(
        'subject' => 'Nouvelle réunion créée',
        'text' => 'Une nouvelle réunion a été créée.',
    ),
    'meetingReminder' => 
    array (
        'subject' => 'Rappel de réunion',
        'text' => 'C\'est pour vous rappeler la réunion suivante.',
    ),
    'loginDashboard' => 'Connectez-vous au tableau de bord',
    'thankyouNote' => 'Merci d\'avoir utilisé notre application!',
    'hello' => 'Bonjour',
);
