<?php

return [
    'name' => 'Zoom',
    'verification_required' => true,
    'envato_item_id' => 29292666,
	'parent_envato_id' => 23263417,
    'script_name' => 'worksuite-saas-zoom',
    'setting' => \Modules\Zoom\Entities\ZoomSetting::class
];
